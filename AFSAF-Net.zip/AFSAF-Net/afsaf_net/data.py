"""
Dataset and data loading utilities for AFSAF-Net.

Expected dataset layout (MC4L-IMU platform):
    root/
        train.csv          # or train.jsonl
        val.csv
        images/
            <sample_id>.jpg   # 640×480 RGB
            ...
        imus/
            <sample_id>.npy   # (6,) array [ax, ay, az, ωx, ωy, ωz]
            ...

CSV columns: sample_id, x, y, z, theta
"""

from __future__ import annotations

import os
from typing import Callable

import numpy as np
try:
    import pandas as pd
except ImportError:  # pandas only needed for real CSV data, not for dummy loader
    pd = None
import torch
from torch.utils.data import Dataset, DataLoader
try:
    from PIL import Image
    from torchvision import transforms
except ImportError:
    Image = None
    transforms = None


# ---------------------------------------------------------------------------
# Dataset
# ---------------------------------------------------------------------------
class AFSAFDataset(Dataset):
    """
    RGB + IMU multimodal indoor localization dataset.

    Each sample is one synchronized RGB frame + one IMU measurement → (x, y, z, θ).
    """

    def __init__(
        self,
        csv_path: str,
        image_dir: str,
        imu_dir: str,
        image_size: tuple[int, int] = (480, 640),
        image_transform: Callable | None = None,
        imu_normalize: bool = True,
        imu_mean: np.ndarray | None = None,
        imu_std: np.ndarray | None = None,
    ):
        self.df = pd.read_csv(csv_path)
        self.image_dir = image_dir
        self.imu_dir = imu_dir
        self.imu_normalize = imu_normalize

        # Default image transforms: resize + normalize
        if image_transform is None:
            self.image_transform = transforms.Compose([
                transforms.Resize(image_size),
                transforms.ToTensor(),                 # [0, 1] range, (C, H, W)
                transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                     std=[0.229, 0.224, 0.225]),
            ])
        else:
            self.image_transform = image_transform

        # IMU statistics (per-channel), shape (6,)
        if imu_normalize:
            if imu_mean is None or imu_std is None:
                # Compute from data directory
                all_imus = []
                for sid in self.df["sample_id"]:
                    p = os.path.join(imu_dir, f"{sid}.npy")
                    if os.path.exists(p):
                        all_imus.append(np.load(p))
                all_imus = np.stack(all_imus)
                self.imu_mean = all_imus.mean(axis=0).astype(np.float32)
                self.imu_std = all_imus.std(axis=0).astype(np.float32) + 1e-8
            else:
                self.imu_mean = np.array(imu_mean, dtype=np.float32)
                self.imu_std = np.array(imu_std, dtype=np.float32)

        # Target normalization (per output) — compute from loaded targets
        targets = self.df[["x", "y", "z", "theta"]].values.astype(np.float32)
        self.target_mean = targets.mean(axis=0)
        self.target_std = targets.std(axis=0) + 1e-8

    def __len__(self) -> int:
        return len(self.df)

    def __getitem__(self, idx: int) -> dict:
        row = self.df.iloc[idx]
        sid = row["sample_id"]

        # --- Image ---
        img_path = os.path.join(self.image_dir, f"{sid}.jpg")
        img = Image.open(img_path).convert("RGB")
        img = self.image_transform(img)            # (3, H, W)

        # --- IMU ---
        imu_path = os.path.join(self.imu_dir, f"{sid}.npy")
        imu = np.load(imu_path).astype(np.float32)  # (6,)
        if self.imu_normalize:
            imu = (imu - self.imu_mean) / self.imu_std

        # --- Target ---
        target = np.array([row["x"], row["y"], row["z"], row["theta"]], dtype=np.float32)
        target_norm = (target - self.target_mean) / self.target_std

        return {
            "img": img,                              # (3, H, W) tensor
            "imu": torch.from_numpy(imu),            # (6,) tensor
            "target": torch.from_numpy(target_norm), # (4,) normalized
            "target_raw": torch.from_numpy(target),  # (4,) raw — for metric
        }


# ---------------------------------------------------------------------------
# Build dataloaders
# ---------------------------------------------------------------------------
def build_dataloaders(
    train_csv: str,
    val_csv: str | None,
    image_dir: str,
    imu_dir: str,
    batch_size: int = 16,
    num_workers: int = 4,
    image_size: tuple[int, int] = (480, 640),
) -> tuple[DataLoader, DataLoader | None]:
    train_ds = AFSAFDataset(
        csv_path=train_csv,
        image_dir=image_dir,
        imu_dir=imu_dir,
        image_size=image_size,
        imu_normalize=True,
    )
    train_loader = DataLoader(
        train_ds, batch_size=batch_size, shuffle=True,
        num_workers=num_workers, pin_memory=True,
        drop_last=False,
    )

    val_loader = None
    if val_csv is not None and os.path.exists(val_csv):
        val_ds = AFSAFDataset(
            csv_path=val_csv,
            image_dir=image_dir,
            imu_dir=imu_dir,
            image_size=image_size,
            imu_normalize=True,
            imu_mean=train_ds.imu_mean,
            imu_std=train_ds.imu_std,
        )
        val_loader = DataLoader(
            val_ds, batch_size=batch_size, shuffle=False,
            num_workers=num_workers, pin_memory=True,
        )

    return train_loader, val_loader


# ---------------------------------------------------------------------------
# Demo: build a dummy dataset for testing
# ---------------------------------------------------------------------------
def make_dummy_loader(batch_size: int = 2) -> tuple[DataLoader, tuple[np.ndarray, np.ndarray]]:
    """Generate synthetic samples (no files on disk) for smoke-testing the model."""

    class _DummyDS(Dataset):
        def __init__(self, n: int = 16, img_size: tuple[int, int] = (480, 640)):
            self.n = n
            self.img_size = img_size
            self.target_mean = np.zeros(4, dtype=np.float32)
            self.target_std = np.ones(4, dtype=np.float32)

        def __len__(self):
            return self.n

        def __getitem__(self, idx):
            target = np.random.randn(4).astype(np.float32)
            return {
                "img": torch.randn(3, *self.img_size),
                "imu": torch.randn(6),
                "target": torch.from_numpy(target),
                "target_raw": torch.from_numpy(target),
            }

    ds = _DummyDS()
    return DataLoader(ds, batch_size=batch_size), (ds.target_mean, ds.target_std)


if __name__ == "__main__":
    # Quick smoke test
    loader, (tm, ts) = make_dummy_loader(batch_size=4)
    batch = next(iter(loader))
    print(f"img: {batch['img'].shape}")       # (4, 3, 480, 640)
    print(f"imu: {batch['imu'].shape}")       # (4, 6)
    print(f"target: {batch['target'].shape}") # (4, 4)
    print(f"target_mean: {tm}, target_std: {ts}")

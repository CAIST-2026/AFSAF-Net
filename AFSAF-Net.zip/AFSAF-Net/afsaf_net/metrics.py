"""
Prediction Stability Index (PSI) — Section 4 stability metric.

PSI quantifies the distribution shift between training predictions and
test predictions, used in the paper to evaluate how stable localization
predictions remain across visual conditions.

PSI = Σ [ (actual_rate - expected_rate) · ln(actual_rate / expected_rate) ]
"""

from __future__ import annotations

import numpy as np


def compute_psi(
    expected: np.ndarray,
    actual: np.ndarray,
    bins: int = 10,
    eps: float = 1e-8,
) -> float:
    """
    Compute Prediction Stability Index.

    Args:
        expected: reference (e.g. train) predictions or errors.
        actual:   current  (e.g. test)  predictions or errors.
        bins:     number of equal-width bins.
        eps:      numerical safety for log(0) avoidance.

    Returns:
        psi_value: scalar PSI (0 = identical distributions; larger = more shift).
    """
    expected = np.asarray(expected, dtype=np.float64)
    actual   = np.asarray(actual,   dtype=np.float64)

    # Bins defined on the reference distribution
    lo, hi = expected.min(), expected.max()
    edges = np.linspace(lo, hi, bins + 1)
    edges[0]  = -np.inf
    edges[-1] =  np.inf

    ref_counts, _ = np.histogram(expected, bins=edges)
    cur_counts, _ = np.histogram(actual,   bins=edges)

    ref_rate = (ref_counts + eps) / ref_counts.sum()
    cur_rate = (cur_counts + eps) / cur_counts.sum()

    return float(np.sum((cur_rate - ref_rate) * np.log(cur_rate / ref_rate)))


def compute_psi_multiscale(
    expected_errors: dict[str, np.ndarray],
    actual_errors: dict[str, np.ndarray],
) -> dict[str, float]:
    """
    Compute PSI for each per-position prediction error distribution.

    Args:
        expected_errors: {position_id: error_array} from training / baseline
        actual_errors:   {position_id: error_array} from current model

    Returns:
        {position_id: psi_value} — PSI per measurement position.
    """
    return {
        pid: compute_psi(expected_errors[pid], actual_errors[pid])
        for pid in expected_errors if pid in actual_errors
    }


if __name__ == "__main__":
    # Reproduce paper-style synthetic PSI comparison
    rng = np.random.default_rng(42)
    baseline = rng.normal(1.0, 0.3, size=200)
    stable   = rng.normal(1.0, 0.3, size=200)          # same dist → PSI ≈ 0
    shifted  = rng.normal(1.5, 0.5, size=200)          # shifted   → PSI > 0

    print(f"PSI (identical):     {compute_psi(baseline, stable):.5f}")
    print(f"PSI (shifted dist):  {compute_psi(baseline, shifted):.5f}")

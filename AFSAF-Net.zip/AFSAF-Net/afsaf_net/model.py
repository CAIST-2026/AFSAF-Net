"""
AFSAF-Net: Adaptive Frequency-Spatial Attention Fusion Network with IMU Guidance
Reference: Yin et al., 2026

Architecture (5 components):
    1. Spatial Feature Branch      — CNN encoder on raw RGB image
    2. Adaptive Frequency Branch   — FFT + learnable spectral encoder
    3. Attention Fusion Module     — A = σ(W·[F_s, F_f] + b); F_v = A⊙F_s + (1−A)⊙F_f
    4. IMU Reliability Gate        — G = σ(W_g·F_i + b_g); F_out = G⊙F_i + (1−G)⊙F_v
    5. Localization Prediction Head— FC regression to [x, y, z, θ]
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


# ---------------------------------------------------------------------------
# Utility: BottleNeck Residual Block
# ---------------------------------------------------------------------------
class BottleNeck(nn.Module):
    """Standard bottleneck residual block used in the visual branches."""

    def __init__(self, channels: int, reduction: int = 4):
        super().__init__()
        mid = max(channels // reduction, 8)
        self.conv1 = nn.Conv2d(channels, mid, 1, bias=False)
        self.bn1 = nn.BatchNorm2d(mid)
        self.conv2 = nn.Conv2d(mid, mid, 3, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(mid)
        self.conv3 = nn.Conv2d(mid, channels, 1, bias=False)
        self.bn3 = nn.BatchNorm2d(channels)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        out = self.relu(self.bn1(self.conv1(x)))
        out = self.relu(self.bn2(self.conv2(out)))
        out = self.bn3(self.conv3(out))
        return self.relu(out + residual)


# ---------------------------------------------------------------------------
# 1. Spatial Feature Branch (Section 3.2)
# ---------------------------------------------------------------------------
class SpatialBranch(nn.Module):
    """
    Hierarchical CNN encoder that extracts local texture, edge, and structural
    information directly from the degraded RGB image.

    I ∈ R^{H×W×3}  →  F_s ∈ R^{C×H'×W'}
    """

    def __init__(self, in_channels: int = 3, out_channels: int = 128):
        super().__init__()
        self.stem = nn.Sequential(
            nn.Conv2d(in_channels, 32, 3, stride=2, padding=1, bias=False),  # H→H/2
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),
            nn.Conv2d(32, 64, 3, stride=2, padding=1, bias=False),           # →H/4
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.Conv2d(64, 128, 3, stride=2, padding=1, bias=False),          # →H/8
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.Conv2d(128, 256, 3, stride=2, padding=1, bias=False),         # →H/16
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
        )
        self.stage1 = nn.Sequential(
            nn.Conv2d(256, out_channels, 3, stride=1, padding=1, bias=False),  # keep spatial size
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )
        self.residuals = nn.Sequential(
            BottleNeck(out_channels),
            BottleNeck(out_channels),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.stem(x)
        x = self.stage1(x)
        x = self.residuals(x)
        return x


# ---------------------------------------------------------------------------
# 2. Adaptive Frequency Branch (Section 3.3)
# ---------------------------------------------------------------------------
class FrequencyBranch(nn.Module):
    """
    Learnable frequency-domain encoder.

    Unlike handcrafted FFT enhancement, this branch:
      1. Computes the 2-D FFT of the input image.
      2. Extracts log-magnitude and phase components (6 channels).
      3. Applies a small CNN + residual bottlenecks to learn which spectral
         components are informative under the current environmental condition.

    I ∈ R^{H×W×3}  →  F_f ∈ R^{C×H'×W'}
    """

    def __init__(self, in_channels: int = 6, out_channels: int = 128):
        super().__init__()
        self.stem = nn.Sequential(
            nn.Conv2d(in_channels, 32, 3, stride=2, padding=1, bias=False),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),
            nn.Conv2d(32, 64, 3, stride=2, padding=1, bias=False),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.Conv2d(64, 128, 3, stride=2, padding=1, bias=False),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.Conv2d(128, 256, 3, stride=2, padding=1, bias=False),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
        )
        self.stage1 = nn.Sequential(
            nn.Conv2d(256, out_channels, 3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )
        self.residuals = nn.Sequential(
            BottleNeck(out_channels),
            BottleNeck(out_channels),
        )

    @staticmethod
    def _fft_features(img: torch.Tensor) -> torch.Tensor:
        """Compute 2-D FFT log-magnitude + phase, concatenate along channel dim."""
        fft = torch.fft.fft2(img, dim=(-2, -1))
        fft = torch.fft.fftshift(fft, dim=(-2, -1))
        mag = torch.log(torch.abs(fft) + 1.0)
        phase = torch.angle(fft)
        return torch.cat([mag, phase], dim=1)  # (B, 6, H, W)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self._fft_features(x)
        x = self.stem(x)
        x = self.stage1(x)
        x = self.residuals(x)
        return x


# ---------------------------------------------------------------------------
# 3. Attention Fusion Module (Section 3.4)
# ---------------------------------------------------------------------------
class AttentionFusion(nn.Module):
    """
    Adaptively fuse spatial and frequency feature maps.

    A = σ(W_a · [F_s, F_f] + b_a)                (eq. 10)
    F_v = A ⊙ F_s + (1 − A) ⊙ F_f                (eq. 11)
    """

    def __init__(self, channels: int = 64):
        super().__init__()
        self.proj = nn.Sequential(
            nn.Conv2d(channels * 2, channels, kernel_size=1, bias=True),
            nn.Sigmoid(),
        )

    def forward(self, F_s: torch.Tensor, F_f: torch.Tensor) -> torch.Tensor:
        attn = self.proj(torch.cat([F_s, F_f], dim=1))
        return attn * F_s + (1.0 - attn) * F_f


# ---------------------------------------------------------------------------
# 4. IMU Reliability Gate (Section 3.5)
# ---------------------------------------------------------------------------
class IMUReliabilityGate(nn.Module):
    """
    IMU encoder + reliability gate for adaptive visual-inertial fusion.

    M = [a_x, a_y, a_z, ω_x, ω_y, ω_z]                    (eq. 12)
    F_i = f_i(M; θ_i)                                       (eq. 13)
    G   = σ(W_g · F_i + b_g)                                (eq. 14)
    F_out = G ⊙ F_i + (1 − G) ⊙ F_v                         (eq. 15)
    """

    def __init__(self, imu_dim: int = 6, hidden_dim: int = 64, out_dim: int = 64):
        super().__init__()
        self.imu_encoder = nn.Sequential(
            nn.Linear(imu_dim, hidden_dim),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_dim, out_dim),
        )
        self.gate = nn.Sequential(
            nn.Linear(out_dim, out_dim // 2),
            nn.ReLU(inplace=True),
            nn.Linear(out_dim // 2, out_dim),
            nn.Sigmoid(),
        )

    def forward(self, imu: torch.Tensor, F_v: torch.Tensor) -> torch.Tensor:
        """
        Args:
            imu: (B, imu_dim) raw IMU measurement [ax, ay, az, ωx, ωy, ωz]
            F_v: (B, C, H', W') fused visual feature from AttentionFusion
        """
        F_i = self.imu_encoder(imu)                     # (B, C)
        G = self.gate(F_i)                              # (B, C)
        G = G[:, :, None, None].expand_as(F_v)          # broadcast to (B, C, H', W')
        F_i_expanded = F_i[:, :, None, None].expand_as(F_v)
        return G * F_i_expanded + (1.0 - G) * F_v


# ---------------------------------------------------------------------------
# 5. Localization Prediction Head (Section 3.6)
# ---------------------------------------------------------------------------
class LocalizationHead(nn.Module):
    """
    Regression head that predicts the target localization parameters
    P = [x, y, z, θ]                                         (eq. 16)
    L = (1/N) Σ ||P_i − P̂_i||²                              (eq. 17)
    """

    def __init__(self, in_features: int = 64 * 5 * 5, hidden_dim: int = 512, out_dim: int = 4):
        super().__init__()
        self.head = nn.Sequential(
            nn.Flatten(),
            nn.Linear(in_features, hidden_dim),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3),
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(inplace=True),
            nn.Dropout(0.2),
            nn.Linear(hidden_dim // 2, out_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.head(x)


# ---------------------------------------------------------------------------
# Full AFSAF-Net (Figure 1)
# ---------------------------------------------------------------------------
class AFSAFNet(nn.Module):
    """
    Complete Adaptive Frequency-Spatial Attention Fusion Network.

    Inputs:
        img: (B, 3, 480, 640)   RGB image (MC4L-IMU: 640×480)
        imu: (B, 6)             IMU measurement [ax, ay, az, ωx, ωy, ωz]
    Output:
        pred: (B, 4)            [x, y, z, θ] — position + orientation
    """

    def __init__(
        self,
        image_size: tuple[int, int] = (480, 640),
        spatial_channels: int = 128,
        imu_dim: int = 6,
        num_outputs: int = 4,
        pool_size: tuple[int, int] = (5, 5),
        return_intermediates: bool = False,
    ):
        super().__init__()
        self.return_intermediates = return_intermediates

        self.spatial_branch = SpatialBranch(3, spatial_channels)
        self.frequency_branch = FrequencyBranch(6, spatial_channels)
        self.attn_fusion = AttentionFusion(spatial_channels)
        self.imu_gate = IMUReliabilityGate(imu_dim, hidden_dim=32, out_dim=spatial_channels)
        self.pool = nn.AdaptiveAvgPool2d(pool_size)
        self.head = LocalizationHead(
            in_features=spatial_channels * pool_size[0] * pool_size[1],
            hidden_dim=512,
            out_dim=num_outputs,
        )

    def forward(
        self,
        img: torch.Tensor,
        imu: torch.Tensor,
        return_intermediates: bool | None = None,
    ) -> torch.Tensor | tuple[torch.Tensor, dict[str, torch.Tensor]]:
        F_s = self.spatial_branch(img)                 # (B, C, H', W')
        F_f = self.frequency_branch(img)               # (B, C, H', W')
        F_v = self.attn_fusion(F_s, F_f)               # (B, C, H', W')
        F_out = self.imu_gate(imu, F_v)                # (B, C, H', W')
        pred = self.head(self.pool(F_out))             # (B, 4)

        do_ret = self.return_intermediates if return_intermediates is None else return_intermediates
        if do_ret:
            intermediates = {"F_s": F_s, "F_f": F_f, "F_v": F_v, "F_out": F_out}
            return pred, intermediates
        return pred


# ---------------------------------------------------------------------------
# Instantiation helper
# ---------------------------------------------------------------------------
def build_afsaf_net(image_size: tuple[int, int] = (480, 640)) -> AFSAFNet:
    """Factory function for paper-matching configuration."""
    return AFSAFNet(image_size=image_size)


if __name__ == "__main__":
    model = build_afsaf_net()
    dummy_img = torch.randn(2, 3, 480, 640)
    dummy_imu = torch.randn(2, 6)
    with torch.no_grad():
        out = model(dummy_img, dummy_imu)
    p = sum(pp.numel() for pp in model.parameters()) / 1e6
    print(f"Output: {out.shape}, Params: {p:.2f} M")
    for n, m in model.named_children():
        pp = sum(x.numel() for x in m.parameters()) / 1e6
        print(f"  {n}: {pp:.3f} M")

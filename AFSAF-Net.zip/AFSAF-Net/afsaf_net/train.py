"""
Training & evaluation script for AFSAF-Net.

Usage:
    python -m afsaf_net.train                         # smoke test with dummy data
    python -m afsaf_net.train --train_csv data/train.csv \
                               --val_csv   data/val.csv   \
                               --image_dir data/images    \
                               --imu_dir   data/imus      \
                               --epochs 50 --batch_size 16
"""

from __future__ import annotations

import argparse
import os
import time
from dataclasses import dataclass, asdict

import numpy as np
import torch
import torch.nn as nn
from torch.optim import AdamW
from torch.utils.data import DataLoader

from .model import build_afsaf_net
from .data import AFSAFDataset, make_dummy_loader


# ---------------------------------------------------------------------------
# Metrics
# ---------------------------------------------------------------------------
def compute_metrics(pred_raw: torch.Tensor, tgt_raw: torch.Tensor) -> dict:
    """
    Compute localization metrics on *denormalized* predictions.

    Args:
        pred_raw: (N, 4) — [x, y, z, θ]
        tgt_raw:  (N, 4)
    Returns:
        dict with: mle, rmse_xyz, rmse_theta, mae_xyz, r2
    """
    pred = pred_raw.cpu().numpy()
    tgt = tgt_raw.cpu().numpy()

    # Per-dimension errors
    diff = pred - tgt                                    # (N, 4)

    # MLE: 3D Euclidean distance
    mle = np.mean(np.linalg.norm(diff[:, :3], axis=1))

    # RMSE per group
    rmse_xyz = np.sqrt(np.mean(diff[:, :3] ** 2))
    rmse_theta = np.sqrt(np.mean(diff[:, 3] ** 2))

    # MAE (position)
    mae_xyz = np.mean(np.abs(diff[:, :3]))

    # R² (averaged across dims)
    def _r2(p: np.ndarray, t: np.ndarray) -> float:
        ss_res = np.sum((t - p) ** 2)
        ss_tot = np.sum((t - np.mean(t)) ** 2)
        return 1.0 - ss_res / (ss_tot + 1e-10)

    r2 = float(np.mean([_r2(pred[:, d], tgt[:, d]) for d in range(4)]))

    return {
        "mle": float(mle),
        "rmse_xyz": float(rmse_xyz),
        "rmse_theta": float(rmse_theta),
        "mae_xyz": float(mae_xyz),
        "r2": float(r2),
    }


# ---------------------------------------------------------------------------
# Training / validation steps
# ---------------------------------------------------------------------------
def train_one_epoch(
    model: nn.Module,
    loader: DataLoader,
    device: torch.device,
    optimizer: torch.optim.Optimizer,
    loss_fn: nn.Module,
    target_mean: torch.Tensor,
    target_std: torch.Tensor,
) -> dict:
    model.train()
    running_loss = 0.0
    all_preds, all_targets = [], []

    for batch in loader:
        img = batch["img"].to(device)
        imu = batch["imu"].to(device)
        target = batch["target"].to(device)              # normalized

        optimizer.zero_grad()
        pred = model(img, imu)                            # (B, 4)
        loss = loss_fn(pred, target)
        loss.backward()
        optimizer.step()

        running_loss += loss.item()

        # Denormalize for metric
        pred_raw = pred.detach().cpu() * target_std + target_mean
        tgt_raw = batch["target_raw"]
        all_preds.append(pred_raw)
        all_targets.append(tgt_raw)

    all_preds = torch.cat(all_preds)
    all_targets = torch.cat(all_targets)
    metrics = compute_metrics(all_preds, all_targets)
    metrics["loss"] = running_loss / max(len(loader), 1)
    return metrics


@torch.no_grad()
def evaluate(
    model: nn.Module,
    loader: DataLoader,
    device: torch.device,
    loss_fn: nn.Module,
    target_mean: torch.Tensor,
    target_std: torch.Tensor,
) -> dict:
    model.eval()
    running_loss = 0.0
    all_preds, all_targets = [], []

    for batch in loader:
        img = batch["img"].to(device)
        imu = batch["imu"].to(device)
        target = batch["target"].to(device)

        pred = model(img, imu)
        loss = loss_fn(pred, target)
        running_loss += loss.item()

        pred_raw = pred.cpu() * target_std + target_mean
        all_preds.append(pred_raw)
        all_targets.append(batch["target_raw"])

    all_preds = torch.cat(all_preds)
    all_targets = torch.cat(all_targets)
    metrics = compute_metrics(all_preds, all_targets)
    metrics["loss"] = running_loss / max(len(loader), 1)
    return metrics


# ---------------------------------------------------------------------------
# Full training pipeline
# ---------------------------------------------------------------------------
@dataclass
class TrainConfig:
    train_csv: str | None = None
    val_csv: str | None = None
    image_dir: str | None = None
    imu_dir: str | None = None
    epochs: int = 50
    batch_size: int = 16
    lr: float = 1e-3
    weight_decay: float = 1e-4
    num_workers: int = 4
    image_size: tuple[int, int] = (480, 640)
    use_dummy: bool = True                         # smoke-test if no data


def train(cfg: TrainConfig) -> nn.Module:
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[AFSAF-Net] Device: {device}")

    # --- Data ---
    if cfg.use_dummy or cfg.train_csv is None:
        print("[AFSAF-Net] Using synthetic dummy data (smoke test)")
        train_loader, (tmean, tstd) = make_dummy_loader(batch_size=cfg.batch_size)
        target_mean = torch.from_numpy(tmean)
        target_std = torch.from_numpy(tstd)
        val_loader = None
    else:
        train_ds = AFSAFDataset(cfg.train_csv, cfg.image_dir, cfg.imu_dir, cfg.image_size)
        train_loader = DataLoader(
            train_ds, batch_size=cfg.batch_size, shuffle=True,
            num_workers=cfg.num_workers, pin_memory=True,
        )
        target_mean = torch.from_numpy(train_ds.target_mean)
        target_std = torch.from_numpy(train_ds.target_std)

        val_loader = None
        if cfg.val_csv is not None and os.path.exists(cfg.val_csv):
            val_ds = AFSAFDataset(
                cfg.val_csv, cfg.image_dir, cfg.imu_dir, cfg.image_size,
                imu_normalize=True,
                imu_mean=train_ds.imu_mean,
                imu_std=train_ds.imu_std,
            )
            val_loader = DataLoader(
                val_ds, batch_size=cfg.batch_size, shuffle=False,
                num_workers=cfg.num_workers, pin_memory=True,
            )

    target_mean = target_mean.to(device)
    target_std = target_std.to(device)

    # --- Model ---
    model = build_afsaf_net(image_size=cfg.image_size).to(device)
    total_params = sum(p.numel() for p in model.parameters()) / 1e6
    print(f"[AFSAF-Net] Parameters: {total_params:.2f} M")

    # --- Optimizer & Loss ---
    optimizer = AdamW(model.parameters(), lr=cfg.lr, weight_decay=cfg.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=cfg.epochs)
    loss_fn = nn.MSELoss()

    # --- Train loop ---
    best_val_mle = float("inf")
    for epoch in range(1, cfg.epochs + 1):
        t0 = time.time()
        train_m = train_one_epoch(model, train_loader, device, optimizer, loss_fn, target_mean, target_std)
        t1 = time.time()

        log = f"Epoch {epoch:03d} | {t1 - t0:5.1f}s | " \
              f"train_loss={train_m['loss']:.4f} mle={train_m['mle']:.3f} " \
              f"rmse_xyz={train_m['rmse_xyz']:.3f} r2={train_m['r2']:.4f}"

        if val_loader is not None:
            val_m = evaluate(model, val_loader, device, loss_fn, target_mean, target_std)
            log += f" | val_mle={val_m['mle']:.3f} val_r2={val_m['r2']:.4f}"
            if val_m["mle"] < best_val_mle:
                best_val_mle = val_m["mle"]

        print(log)
        scheduler.step()

    print(f"[AFSAF-Net] Best val MLE: {best_val_mle:.3f}")
    return model


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------
def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser("AFSAF-Net Training")
    p.add_argument("--train_csv", type=str, default=None)
    p.add_argument("--val_csv", type=str, default=None)
    p.add_argument("--image_dir", type=str, default=None)
    p.add_argument("--imu_dir", type=str, default=None)
    p.add_argument("--epochs", type=int, default=50)
    p.add_argument("--batch_size", type=int, default=16)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--weight_decay", type=float, default=1e-4)
    p.add_argument("--num_workers", type=int, default=4)
    p.add_argument("--use_dummy", action="store_true", default=False)
    return p.parse_args()


if __name__ == "__main__":
    args = _parse_args()
    cfg = TrainConfig(
        train_csv=args.train_csv,
        val_csv=args.val_csv,
        image_dir=args.image_dir,
        imu_dir=args.imu_dir,
        epochs=args.epochs,
        batch_size=args.batch_size,
        lr=args.lr,
        weight_decay=args.weight_decay,
        num_workers=args.num_workers,
        use_dummy=(args.use_dummy or args.train_csv is None),
    )
    print("=" * 60)
    print("AFSAF-Net Training Config:")
    for k, v in asdict(cfg).items():
        print(f"  {k}: {v}")
    print("=" * 60)
    train(cfg)
